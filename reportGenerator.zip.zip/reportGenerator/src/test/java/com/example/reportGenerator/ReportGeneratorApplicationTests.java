package com.example.reportGenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
